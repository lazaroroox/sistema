
(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
    typeof define === 'function' && define.amd ? define(['exports'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global.Datafeeds = {}));
}(this, (function (exports) { 'use strict';

    /**
     * If you want to enable logs from datafeed set it to `true`
     */
    function logMessage(message) {
    }
    function getErrorMessage(error) {
        if (error === undefined) {
            return '';
        }
        else if (typeof error === 'string') {
            return error;
        }
        return error.message;
    }

        
    /**
    * Esta classe implementa a interação com feed de dados compatível com UDF.
    * Consulte [referência do protocolo UDF] (@docs/connecting_data/UDF.md)
    *  Cria uma instância do DataPulseProvider utilizando WebSocket.
    * @param {string} wsUrl URL do servidor WebSocket.
    * @param {number} [reconnectDelay=3000] Tempo (ms) para tentar reconectar após desconexão.
    */
    class UDFCompatibleDatafeedBase {
        constructor(datafeedURL, requester, wsUrl, reconnectDelay = 3000) {
            this._configuration = defaultConfiguration();
            // Mapeia cada assinante pelo seu listenerGuid.
            this._subscribers = {};
            // Agrupa assinaturas por canal ("símbolo:resolução") para evitar inscrições redundantes.
            this._subscriptionsByChannel = {};  // Exemplo de chave: "btcusd:1"
            // Fila de mensagens que ainda não foram enviadas por conta da conexão não estar aberta.
            this._pendingMessages = [];
            this._wsUrl = wsUrl;
            this._reconnectDelay = reconnectDelay;
            this._connect();
            this._symbolsStorage = null;
            this._datafeedURL = datafeedURL;
            this._requester = requester;
            this.callbacks = {};
            
        }
        /**
         * Cria a conexão WebSocket e atribui os handlers de eventos.
         * Sempre que a conexão for fechada, tenta reconectar.
         */
        _connect() {
            this._ws = new WebSocket(this._wsUrl);
            this._ws.onopen = this._onWsOpen.bind(this);
            this._ws.onmessage = this._onWsMessage.bind(this);
            this._ws.onerror = this._onWsError.bind(this);
            this._ws.onclose = this._onWsClose.bind(this);
        }

        onReady(callback) {
            setTimeout(() => callback(this._configuration));

        }
        getServerTime(callback) {
            if (!this._configuration.supports_time) {
                return;
            }
            this._send('time')
                .then((response) => {
                const time = parseInt(response);
                if (!isNaN(time)) {
                    callback(time);
                }
            })
                .catch((error) => {
                logMessage(`UdfCompatibleDatafeed: Fail to load server time, error=${getErrorMessage(error)}`);
            });
        }
        resolveSymbol(symbolName, onResolve, onError, extension) {
            const currencyCode = extension && extension.currencyCode;
            const unitId = extension && extension.unitId;
            function onResultReady(symbolInfo) {
                onResolve(symbolInfo);
            }
            if (!this._configuration.supports_group_request) {
                const params = {
                    symbol: symbolName,
                };
                if (currencyCode !== undefined) {
                    params.currencyCode = currencyCode;
                }
                if (unitId !== undefined) {
                    params.unitId = unitId;
                }
                this._send('symbols', params)
                    .then((response) => {
                    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1;
                    if (response.s !== undefined) {
                        onError('unknown_symbol');
                    }
                    else {
                        const symbol = response.name;
                        const listedExchange = (_a = response.listed_exchange) !== null && _a !== void 0 ? _a : response['exchange-listed'];
                        const tradedExchange = (_b = response.exchange) !== null && _b !== void 0 ? _b : response['exchange-traded'];
                        const result = {
                            ...response,
                            name: symbol,
                            base_name: [listedExchange + ':' + symbol],
                            listed_exchange: listedExchange,
                            exchange: tradedExchange,
                            ticker: response.ticker,
                            currency_code: (_c = response.currency_code) !== null && _c !== void 0 ? _c : response['currency-code'],
                            original_currency_code: (_d = response.original_currency_code) !== null && _d !== void 0 ? _d : response['original-currency-code'],
                            unit_id: (_e = response.unit_id) !== null && _e !== void 0 ? _e : response['unit-id'],
                            original_unit_id: (_f = response.original_unit_id) !== null && _f !== void 0 ? _f : response['original-unit-id'],
                            unit_conversion_types: (_g = response.unit_conversion_types) !== null && _g !== void 0 ? _g : response['unit-conversion-types'],
                            has_intraday: (_j = (_h = response.has_intraday) !== null && _h !== void 0 ? _h : response['has-intraday']) !== null && _j !== void 0 ? _j : false,
                            visible_plots_set: (_k = response.visible_plots_set) !== null && _k !== void 0 ? _k : response['visible-plots-set'],
                            minmov: (_m = (_l = response.minmovement) !== null && _l !== void 0 ? _l : response.minmov) !== null && _m !== void 0 ? _m : 0,
                            minmove2: (_o = response.minmovement2) !== null && _o !== void 0 ? _o : response.minmove2,
                            session: (_p = response.session) !== null && _p !== void 0 ? _p : response['session-regular'],
                            session_holidays: (_q = response.session_holidays) !== null && _q !== void 0 ? _q : response['session-holidays'],
                            supported_resolutions: (_t = (_s = (_r = response.supported_resolutions) !== null && _r !== void 0 ? _r : response['supported-resolutions']) !== null && _s !== void 0 ? _s : this._configuration.supported_resolutions) !== null && _t !== void 0 ? _t : [],
                            has_daily: (_v = (_u = response.has_daily) !== null && _u !== void 0 ? _u : response['has-daily']) !== null && _v !== void 0 ? _v : true,
                            intraday_multipliers: (_x = (_w = response.intraday_multipliers) !== null && _w !== void 0 ? _w : response['intraday-multipliers']) !== null && _x !== void 0 ? _x : ['1', '5', '15', '30', '60'],
                            has_weekly_and_monthly: (_y = response.has_weekly_and_monthly) !== null && _y !== void 0 ? _y : response['has-weekly-and-monthly'],
                            has_empty_bars: (_z = response.has_empty_bars) !== null && _z !== void 0 ? _z : response['has-empty-bars'],
                            volume_precision: (_0 = response.volume_precision) !== null && _0 !== void 0 ? _0 : response['volume-precision'],
                            format: (_1 = response.format) !== null && _1 !== void 0 ? _1 : 'price',
                        };
                        onResultReady(result);
                    }
                })
                    .catch((reason) => {
                    logMessage(`UdfCompatibleDatafeed: Error resolving symbol: ${getErrorMessage(reason)}`);
                    onError('unknown_symbol');
                });
            }
        }
        async getBars(symbolInfo, resolution, periodParams, onResult, onError) {
            periodParams.to = periodParams.to - 60

            return new Promise((resolve, reject) => {
                const requestId = `${symbolInfo.name}-${Date.now()}-${Math.random().toString(36).substring(2, 10)}`;
    
                const message = {
                    method: "GET_HISTORY",
                    params: {
                        symbol: symbolInfo.name,
                        interval: resolution,
                        to: periodParams.to,
                        countback: periodParams.countBack,
                        firstDataRequest: periodParams.firstDataRequest,
                        callback: requestId
                    },
                };
    
                this.callbacks[requestId] = { onResult, onError };
                this._sendWebSocketMessage(message);
            });
        }
        /**
         * Adiciona um assinante e agrupa por canal.
         * Envia a mensagem de SUBSCRIBE via WebSocket somente se for o primeiro assinante daquele canal.
         * 
         * @param {Object} symbolInfo - Informações do símbolo, ex.: { name: "btcusd" }.
         * @param {string|number} resolution - Intervalo da barra, ex.: "1".
         * @param {Function} newDataCallback - Callback para tratar os dados recebidos.
         * @param {string} listenerGuid - Identificador único do assinante.
         */
        subscribeBars(symbolInfo, resolution, newDataCallback, listenerGuid, _onResetCacheNeededCallback) {
            if (this._subscribers.hasOwnProperty(listenerGuid)) {
                return;
            }
            this._subscribers[listenerGuid] = {
                lastBarTime: null,
                listener: newDataCallback,
                resolution: resolution,
                symbolInfo: symbolInfo,
            };
    
            const channelKey = this._getChannelKey(symbolInfo.name, resolution);
            if (!this._subscriptionsByChannel[channelKey]) {
                this._subscriptionsByChannel[channelKey] = new Set();
                // Envia mensagem de inscrição apenas para o primeiro assinante daquele canal.
                const subscribeMessage = {
                    method: "SUBSCRIBE",
                    params: {
                        symbol: symbolInfo.name,
                        type: "watchOHLCV",
                        interval: resolution.toString(),
                    },
                };
                this._sendWebSocketMessage(subscribeMessage);
                logMessage(`DataPulseProvider: enviou SUBSCRIBE para o canal ${channelKey}`);
            }
            this._subscriptionsByChannel[channelKey].add(listenerGuid);
            logMessage(`DataPulseProvider: inscrito para #${listenerGuid} no canal ${channelKey}`);
        }

        /**
         * Remove o assinante e, se não houver mais assinantes no canal correspondente, envia a mensagem de UNSUBSCRIBE.
         * 
         * @param {string} listenerGuid - Identificador único do assinante.
         */
        unsubscribeBars(listenerGuid) {
            const subscription = this._subscribers[listenerGuid];
            if (subscription) {
                const channelKey = this._getChannelKey(subscription.symbolInfo.name, subscription.resolution);
                if (this._subscriptionsByChannel[channelKey]) {
                    this._subscriptionsByChannel[channelKey].delete(listenerGuid);
                    if (this._subscriptionsByChannel[channelKey].size === 0) {
                        // Se não houver mais assinantes para o canal, envia mensagem de desinscrição.
                        const unsubscribeMessage = {
                            method: "UNSUBSCRIBE",
                            params: {
                                symbol: subscription.symbolInfo.name,
                                type: "watchOHLCV",
                                interval: subscription.resolution.toString(),
                            },
                        };
                        this._sendWebSocketMessage(unsubscribeMessage);
                        delete this._subscriptionsByChannel[channelKey];
                        logMessage(`DataPulseProvider: enviou UNSUBSCRIBE para o canal ${channelKey}`);
                    }
                }
                delete this._subscribers[listenerGuid];
                logMessage(`DataPulseProvider: cancelada inscrição para #${listenerGuid}`);
            }
        }


        /**
         * Gera uma chave para o canal baseado em símbolo e resolução.
         * @param {string} symbol 
         * @param {string|number} resolution 
         * @returns {string} Chave do canal, ex.: "btcusd:1"
         */
        _getChannelKey(symbol, resolution) {
            return `${symbol.toLowerCase()}:${resolution.toString()}`;
        }
    
        /**
         * Envia uma mensagem via WebSocket. Se a conexão não estiver aberta, adiciona a mensagem em uma fila.
         * @param {Object} messageObj Objeto da mensagem a ser enviada.
         */
        _sendWebSocketMessage(messageObj) {
            if (this._ws.readyState === WebSocket.OPEN) {
                this._ws.send(JSON.stringify(messageObj));
            } else {
                logMessage("WebSocket não está aberto; enfileirando mensagem:", messageObj);
                this._pendingMessages.push(messageObj);
            }
        }
    
        /**
         * Tenta enviar todas as mensagens pendentes na fila.
         */
        _flushPendingMessages() {
            while (this._pendingMessages.length > 0) {
                const msg = this._pendingMessages.shift();
                this._sendWebSocketMessage(msg);
            }
        }
    
        /**
         * Handler do evento onopen do WebSocket.
         * Reenvia todas as mensagens pendentes e reinscreve todos os canais.
         */
        _onWsOpen(event) {
            logMessage("Conexão WebSocket estabelecida.");
            this._flushPendingMessages();
            // Reinscreve todos os canais que estão ativos.
            for (const channelKey in this._subscriptionsByChannel) {
                const [symbol, resolution] = channelKey.split(":");
                const subscribeMessage = {
                    method: "SUBSCRIBE",
                    params: {
                        symbol: symbol,
                        type: "watchOHLCV",
                        interval: resolution,
                    },
                };
                this._sendWebSocketMessage(subscribeMessage);
                logMessage(`DataPulseProvider: reinscreveu o canal ${channelKey}`);
            }
        }
    
        /**
         * Handler do evento onmessage do WebSocket.
         * Processa as mensagens recebidas e verifica se contém dados watchOHLCV.
         */
        _onWsMessage(event) {
            try {
                const data = JSON.parse(event.data);
                if (data.historyOHLCV && data.historyOHLCV.callback && this.callbacks[data.historyOHLCV.callback]) {
                    const dados = data.historyOHLCV;
                    const callback = this.callbacks[dados.callback];
                    delete this.callbacks[dados.callback];
                    const result = this._OHLCVDATA(dados)
                    if (dados.s === "ok") {
                        callback.onResult(result.bars, result.meta);
                    } else {
                        callback.onError(data.msg || "Error fetching bars");
                    }
                }
                if (data.watchOHLCV) {
                    this._handleOHLCVData(data.watchOHLCV);
                }
            } catch (e) {
                console.error("Erro ao processar mensagem WS:", event.data, e);
            }
        }
    
        /**
         * Processa os dados do tipo watchOHLCV e distribui para os assinantes do canal correspondente.
         * A estrutura esperada é:
         * {
         *    "s": "ok",
         *    "symbol": "btcusd",
         *    "interval": "1",
         *    "t": [1744680300, 1744680360],
         *    "o": [84845.12, 84901.12],
         *    "h": [84915.53, 84914.19],
         *    "l": [84829.83, 84861.26],
         *    "c": [84900.97, 84894.63],
         *    "v": [343.0, 218.0]
         * }
         * 
         * @param {Object} payload Dados recebidos.
         */
        _OHLCVDATA(response){
            if (response.s !== 'ok' && response.s !== 'no_data') {
                return;
            }
            const bars = [];
            const meta = {
                noData: false,
            };
            if (response.s === 'no_data') {
                meta.noData = true;
                meta.nextTime = response.nextTime;
            }
            else {
                const volumePresent = response.v !== undefined;
                const ohlPresent = response.o !== undefined;
                for (let i = 0; i < response.t.length; ++i) {
                    const barValue = {
                        time: response.t[i] * 1000,
                        close: parseFloat(response.c[i]),
                        open: parseFloat(response.c[i]),
                        high: parseFloat(response.c[i]),
                        low: parseFloat(response.c[i]),
                    };
                    if (ohlPresent) {
                        barValue.open = parseFloat(response.o[i]);
                        barValue.high = parseFloat(response.h[i]);
                        barValue.low = parseFloat(response.l[i]);
                    }
                    if (volumePresent) {
                        barValue.volume = parseFloat(response.v[i]);
                    }
                    bars.push(barValue);
                }
            }
            return {
                bars: bars,
                meta: meta,
            };
        }
        _handleOHLCVData(payload) {
            if (!payload || payload.s !== "ok") {
                return;
            }
            const symbol = payload.symbol;
            const interval = payload.interval.toString();
            const channelKey = this._getChannelKey(symbol, interval);
    
            // Constroi o array de barras assumindo que os arrays (t, o, h, l, c, v) tenham o mesmo tamanho.
            let bars = [];
            for (let i = 0; i < payload.t.length; i++) {
                bars.push({
                    time: payload.t[i] * 1000,
                    open: payload.o[i],
                    high: payload.h[i],
                    low: payload.l[i],
                    close: payload.c[i],
                    volume: payload.v[i],
                });
            }
    
            // Envia os dados apenas para os assinantes que pertencem a este canal.
            if (this._subscriptionsByChannel[channelKey]) {
                for (const listenerGuid of this._subscriptionsByChannel[channelKey]) {
                    const subscription = this._subscribers[listenerGuid];
                    if (subscription) {
                        const newLastBar = bars[bars.length - 1];
                        // Se detectar que houve atualização do bar, envia primeiramente o bar anterior (caso exista).
                        if (subscription.lastBarTime !== null && newLastBar.time > subscription.lastBarTime) {
                            if (bars.length < 2) {
                                console.error("Não há barras suficientes para atualização adequada. São necessárias pelo menos 2.");
                                continue;
                            }
                            const previousBar = bars[bars.length - 2];
                            subscription.listener(previousBar);
                        }
                        subscription.lastBarTime = newLastBar.time;
                        subscription.listener(newLastBar);
                    }
                }
            }
        }
    
        /**
         * Handler do evento onerror do WebSocket.
         */
        _onWsError(event) {
            console.error("Erro no WebSocket:", event);
        }
    
        /**
         * Handler do evento onclose do WebSocket.
         * Tenta reconectar após um atraso definido.
         */
        _onWsClose(event) {
            logMessage("Conexão WebSocket fechada, tentando reconectar...");
            setTimeout(() => {
                this._connect();
            }, this._reconnectDelay);
        }
        _requestConfiguration() {
            return this._send('config')
                .catch((reason) => {
                logMessage(`UdfCompatibleDatafeed: Cannot get datafeed configuration - use default, error=${getErrorMessage(reason)}`);
                return null;
            });
        }
        _send(urlPath, params) {
            return this._requester.sendRequest(this._datafeedURL, urlPath, params);
        }
    }
    function defaultConfiguration() {
        return {
            "supports_search": true,
            "supports_group_request": false,
            "supports_marks": false,
            "supports_timescale_marks": false,
            "supported_resolutions": [
                "1",
                "5",
                "10",
                "15",
                "30",
                "60",
                "120",
                "180",
                "240",
                "300",
                "480",
                "600",
                "900",
                "1440",
                "1800",
                "3600",
                "D",
                "W"
            ]
        };
    }

    class QuotesProvider {
        constructor(datafeedUrl, requester) {
            this._datafeedUrl = datafeedUrl;
            this._requester = requester;
        }
        getQuotes(symbols) {
            return new Promise((resolve, reject) => {
                this._requester.sendRequest(this._datafeedUrl, 'quotes', { symbols: symbols })
                    .then((response) => {
                    if (response.s === 'ok') {
                        resolve(response.d);
                    }
                    else {
                        reject(response.errmsg);
                    }
                })
                    .catch((error) => {
                    const errorMessage = getErrorMessage(error);
                    reject(`network error: ${errorMessage}`);
                });
            });
        }
    }

    class Requester {
        constructor(headers) {
            if (headers) {
                this._headers = headers;
            }
        }
        sendRequest(datafeedUrl, urlPath, params) {
            if (params !== undefined) {
                const paramKeys = Object.keys(params);
                if (paramKeys.length !== 0) {
                    urlPath += '?';
                }
                urlPath += paramKeys.map((key) => {
                    return `${encodeURIComponent(key)}=${encodeURIComponent(params[key].toString())}`;
                }).join('&');
            }
            // Send user cookies if the URL is on the same origin as the calling script.
            const options = { credentials: 'same-origin' };
            if (this._headers !== undefined) {
                options.headers = this._headers;
            }
            // eslint-disable-next-line no-restricted-globals
            return fetch(`${datafeedUrl}/${urlPath}`, options)
                .then((response) => response.text())
                .then((responseTest) => JSON.parse(responseTest));
        }
    }

    class UDFCompatibleDatafeed extends UDFCompatibleDatafeedBase {
        constructor(datafeedURL, wsURL) {
            const requester = new Requester();
            super(datafeedURL, requester, wsURL);
        }
        
    }

    exports.UDFCompatibleDatafeed = UDFCompatibleDatafeed;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
