<?php

    $afiliadosID = array(
        'plataforma.vortexcripto.site' => 5642,
        'plataforma.kyron.space'    => 9981
    );